package com.musaddiqbaluch.census;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.ColorUtils;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.color.MaterialColors;
import com.google.android.material.color.utilities.DynamicScheme;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Material 3 Expressive wavy distribution progress bar + artwork-driven
 * color panel.
 *
 * Requires: com.google.android.material:material:1.14.0 or newer.
 *
 * Seed extraction: MCU Score with Palette fallback (via ArtworkColorHelper).
 * Scheme generation: SchemeVibrant (via ArtworkColorHelper).
 *
 * Every artwork-driven view inside bodyOutline is painted from ONE
 * DynamicScheme and crossfaded by parallel ValueAnimators of identical
 * duration and interpolator. The cookie ripple rings and glow both follow
 * the indicator color; the glow is drawn at low alpha as an M3 state
 * layer so every installer gets a tint of the same lightness.
 *
 * Progress model
 * --------------
 *   The indicator always uses a fixed max of PROGRESS_MAX (10000) and the
 *   installer share is converted to that scale. Any non-zero share is
 *   raised to at least MIN_VISIBLE_THICKNESS_MULTIPLIER x track thickness
 *   (in pixels), so a tiny share never collapses into a leaf/blob shape.
 *
 * Threading model
 * ---------------
 *   Public API is safe to call from any thread. Internally, every entry
 *   point marshals to the main thread before touching views or animators.
 *   PackageManager lookups, extraction, and scheme generation run on a
 *   single-threaded bgExecutor, wrapped in try/catch.
 *
 * Fallbacks
 * ---------
 *   - Any failure in createInstallerColors falls back to createTotalColors.
 *   - Any failure in createTotalColors falls back to hardcoded M3 defaults.
 *   - Any failure in a render step falls back to applyAllRoles(total).
 *   - Every static theme reader returns its fallback parameter on failure.
 *
 * Pending-state behaviour
 * -----------------------
 *   When an installer is selected but its source color is not yet cached,
 *   the renderer does NOT touch the current visual state. It only updates
 *   the progress bar and schedules the background color task. When the
 *   task completes, the colors crossfade from whatever was on screen to
 *   the new installer's palette. This avoids a visible flicker on the
 *   first tap of an installer whose colors aren't known yet.
 */
public final class MaterialDistributionBar {

    private static final String TAG = "DistBar";

    private static final String TOTAL_KEY = "total_user_apps";

    // This class's own sentinel, used when setDistributionOnMain() has to
    // fabricate an Unknown bucket for the "missing count" remainder.
    private static final String UNKNOWN_KEY = "unknown";

    private static final int UNKNOWN_SEED_COLOR = 0xFFB3261E;

    private static final String PREFS_NAME = "m3_dist_bar_v6";
    private static final String KEY_SELECTED_INSTALLER = "last_selected_key";
    private static final String SOURCE_COLOR_PREFIX = "installer_source_color:";

    // ---- Material 3 Expressive wavy bar configuration ----
    // Google's recommended "thick" track is 8dp with a 4dp corner radius.
    private static final float TRACK_THICKNESS_DP = 8f;
    private static final float WAVELENGTH_DP = 40f;
    private static final float WAVE_AMPLITUDE_DP = 3f;
    private static final float GAP_DP = 4f;
    private static final float STOP_DP = 4f;

    // Fixed indicator scale; the real share is converted to this range.
    private static final int PROGRESS_MAX = 10000;

    // Smallest visible fill = thickness * this multiplier (in pixels).
    private static final float MIN_VISIBLE_THICKNESS_MULTIPLIER = 1.0f;

    // Space kept free at the end of the track so even a full bar never
    // touches the end: GAP_DP of indicator/track gap plus a small piece of
    // visible track holding the stop dot. Raise for a bigger gap.
    private static final float END_GAP_DP = 16f;

    private static final long COLOR_ANIM_MS = 300L;
    private static final long LAUNCH_ANIM_MS = 650L;

    private static final float BORDER_LIGHTEN_AMOUNT = 0.35f;

    // Length of the fade at the left and right end of both divider lines
    // (borderLayout and borderLayout2). 0 turns the fade off.
    private static final float BORDER_FADE_DP = 145f;

    private static final int DEFAULT_PRIMARY_LIGHT = 0xFF6750A4;
    private static final int DEFAULT_PRIMARY_DARK  = 0xFFD0BCFF;

    private static final int DEFAULT_ON_PRIMARY_LIGHT = 0xFFFFFFFF;
    private static final int DEFAULT_ON_PRIMARY_DARK  = 0xFF381E72;

    private static final int DEFAULT_SURFACE_LIGHT = 0xFFE6E0E9;
    private static final int DEFAULT_SURFACE_DARK  = 0xFF36343B;

    private static final int DEFAULT_SURFACE_CONTAINER_LOW_LIGHT = 0xFFF7F2FA;
    private static final int DEFAULT_SURFACE_CONTAINER_LOW_DARK = 0xFF211F26;

    private static final int DEFAULT_OUTLINE_VARIANT_LIGHT = 0xFFCAC4D0;
    private static final int DEFAULT_OUTLINE_VARIANT_DARK = 0xFF49454F;

    private static final int DEFAULT_PRIMARY_CONTAINER_LIGHT = 0xFFEADDFF;
    private static final int DEFAULT_PRIMARY_CONTAINER_DARK = 0xFF4F378B;

    private static final int DEFAULT_SURFACE_CONTAINER_LIGHT = 0xFFF3EDF7;
    private static final int DEFAULT_SURFACE_CONTAINER_DARK = 0xFF211F26;

    private static final int DEFAULT_SURFACE_BG_LIGHT = 0xFFFFFBFE;
    private static final int DEFAULT_SURFACE_BG_DARK = 0xFF1C1B1F;

    private static final int DEFAULT_SECONDARY_LIGHT = 0xFF625B71;
    private static final int DEFAULT_SECONDARY_DARK = 0xFFCCC2DC;

    private static final int DEFAULT_SECONDARY_CONTAINER_LIGHT = 0xFFE8DEF8;
    private static final int DEFAULT_SECONDARY_CONTAINER_DARK  = 0xFF4A4458;

    private static final int DEFAULT_OUTLINE_LIGHT = 0xFF79747E;
    private static final int DEFAULT_OUTLINE_DARK = 0xFF938F99;

    private final LinearProgressIndicator indicator;

    @Nullable private final View appCountTextLayout;
    @Nullable private final android.widget.TextView appCountText;

    @Nullable private final Cookie12SidedDrawable appCountBackground;

    @Nullable private RoundedShapeDrawable bodyOutlineDrawable;

    @NonNull
    private final List<RoundedShapeDrawable> borderDrawables =
            new ArrayList<RoundedShapeDrawable>();

    @Nullable private RoundedShapeDrawable appCountPillDrawable;
    @Nullable private ImageView appCountIcon;

    @Nullable private RoundedShapeDrawable labelLayoutDrawable;
    @Nullable private ImageView labelIcon;
    @Nullable private android.widget.TextView labelText;

    @Nullable private LottieAnimationView emoDroid;

    @Nullable private CookieRippleView rippleView;

    private final Context context;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService bgExecutor = Executors.newSingleThreadExecutor();
    private final AtomicInteger generation = new AtomicInteger(0);
    private final AtomicBoolean destroyGuard = new AtomicBoolean(false);
    private final SharedPreferences prefs;

    private final Map<String, Integer> sourceColorCache = new BoundedColorCache();
    private final Map<String, String> packageCache = new BoundedPackageCache();
    private final Map<String, Boolean> failedCache = new BoundedFailedCache();

    @Nullable private volatile Map<String, String> installedAppIndex;
    @Nullable private Future<?> activeColorTask;

    // Held as a field so we can detach it in cleanup() -- the anonymous
    // listener would otherwise pin this entire instance to the indicator
    // view across configuration changes.
    @Nullable private View.OnLayoutChangeListener indicatorLayoutListener;

    private int currentTotal = 0;

    private final LinkedHashMap<String, InstallerAggregate> currentAggregates =
            new LinkedHashMap<>();

    private String selectedKey = TOTAL_KEY;
    private boolean hasData = false;
    private volatile boolean destroyed = false;
    private boolean launchStarted = false;
    private int launchToken = 0;

    @Nullable private ValueAnimator launchAnimator;
    @Nullable private ValueAnimator indicatorColorAnim;
    @Nullable private ValueAnimator trackColorAnim;
    @Nullable private ValueAnimator textColorAnim;
    @Nullable private ValueAnimator surfaceColorAnim;
    @Nullable private ValueAnimator outlineColorAnim;
    @Nullable private ValueAnimator pillColorAnim;
    @Nullable private ValueAnimator labelFillColorAnim;
    @Nullable private ValueAnimator labelStrokeColorAnim;
    @Nullable private ValueAnimator secondaryColorAnim;
    @Nullable private ValueAnimator lottieColorAnim;

    @Nullable private String resolvingKey;

    private int lastAppliedIndicatorColor = Color.TRANSPARENT;
    private int lastAppliedOnIndicatorColor = Color.TRANSPARENT;
    private int lastAppliedSurfaceColor = Color.TRANSPARENT;
    private int lastAppliedOutlineColor = Color.TRANSPARENT;
    private int lastAppliedPillColor = Color.TRANSPARENT;
    private int lastAppliedLabelFillColor = Color.TRANSPARENT;
    private int lastAppliedLabelStrokeColor = Color.TRANSPARENT;
    private int lastAppliedSecondaryColor = Color.TRANSPARENT;

    @Nullable private LottieThemeEngine.Roles lastAppliedLottieRoles;

    public MaterialDistributionBar(
            @NonNull LinearProgressIndicator indicator) {
        this(indicator, null, null);
    }

    public MaterialDistributionBar(
            @NonNull LinearProgressIndicator indicator,
            @Nullable View appCountTextLayout) {
        this(indicator, appCountTextLayout, null);
    }

    public MaterialDistributionBar(
            @NonNull LinearProgressIndicator indicator,
            @Nullable View appCountTextLayout,
            @Nullable android.widget.TextView appCountText) {

        this.indicator = indicator;
        this.appCountTextLayout = appCountTextLayout;
        this.appCountText = appCountText;
        this.context = indicator.getContext();

        SharedPreferences localPrefs = null;
        try {
            localPrefs = context.getSharedPreferences(
                    PREFS_NAME,
                    Context.MODE_PRIVATE
            );
        } catch (Throwable t) {
            Log.e(TAG, "Failed to open SharedPreferences", t);
        }
        this.prefs = localPrefs;

        if (appCountTextLayout != null) {
            int seedColor = safeThemeColor(
                    com.google.android.material.R.attr.colorPrimary,
                    DEFAULT_PRIMARY_LIGHT
            );

            Cookie12SidedDrawable background = null;
            try {
                background = new Cookie12SidedDrawable(seedColor);
                appCountTextLayout.setBackground(background);
            } catch (Throwable e) {
                Log.e(TAG, "Failed to set appCountTextLayout background", e);
                background = null;
            }

            this.appCountBackground = background;
        } else {
            this.appCountBackground = null;
        }

        if (appCountText != null) {
            try {
                int seedOnColor = safeThemeColor(
                        com.google.android.material.R.attr.colorOnPrimary,
                        DEFAULT_ON_PRIMARY_LIGHT
                );
                appCountText.setTextColor(seedOnColor);
                lastAppliedOnIndicatorColor = seedOnColor;
            } catch (Throwable e) {
                Log.e(TAG, "Failed to seed appCountText color", e);
            }
        }

        try {
            loadState();
        } catch (Throwable t) {
            Log.e(TAG, "loadState failed", t);
        }

        try {
            configureIndicator();
        } catch (Throwable t) {
            Log.e(TAG, "configureIndicator failed", t);
            // Last-resort paint so the panel is never left unstyled.
            safeApplyTotalColors();
        }
    }

    // ============================================================
    // Attach methods
    // ============================================================

    public void attachBodyOutline(@NonNull RoundedShapeDrawable drawable) {
        try {
            this.bodyOutlineDrawable = drawable;

            int initialFill = lastAppliedSurfaceColor != Color.TRANSPARENT
                    ? lastAppliedSurfaceColor
                    : getSurfaceContainerLowColor();
            applyBodySurfaceColor(initialFill);

            int initialStroke = lastAppliedOutlineColor != Color.TRANSPARENT
                    ? lastAppliedOutlineColor
                    : getOutlineVariantColor();
            applyOutlineVariantColor(initialStroke);
        } catch (Throwable t) {
            Log.e(TAG, "attachBodyOutline failed", t);
        }
    }

    public void attachBorderDrawable(@NonNull RoundedShapeDrawable drawable) {
        try {
            // Fade both ends of the divider. The fade is an alpha mask
            // applied at draw time, so it survives the color crossfades.
            drawable.fadeEdges(BORDER_FADE_DP);

            borderDrawables.add(drawable);

            int initial = lastAppliedOutlineColor != Color.TRANSPARENT
                    ? lastAppliedOutlineColor
                    : getOutlineVariantColor();
            applyOutlineVariantColor(initial);
        } catch (Throwable t) {
            Log.e(TAG, "attachBorderDrawable failed", t);
        }
    }

    public void attachAppCountPill(
            @NonNull RoundedShapeDrawable pill,
            @NonNull ImageView icon) {

        try {
            this.appCountPillDrawable = pill;
            this.appCountIcon = icon;

            int initialPill = lastAppliedPillColor != Color.TRANSPARENT
                    ? lastAppliedPillColor
                    : getPrimaryContainerColor();
            applyAppCountPillColor(initialPill);

            int initialIcon = lastAppliedIndicatorColor != Color.TRANSPARENT
                    ? lastAppliedIndicatorColor
                    : getPrimaryColor();
            applyAppCountIconTint(initialIcon);
        } catch (Throwable t) {
            Log.e(TAG, "attachAppCountPill failed", t);
        }
    }

    public void attachLabelLayout(
            @NonNull RoundedShapeDrawable chip,
            @NonNull ImageView icon,
            @NonNull android.widget.TextView text) {

        try {
            this.labelLayoutDrawable = chip;
            this.labelIcon = icon;
            this.labelText = text;

            int initialFill = lastAppliedLabelFillColor != Color.TRANSPARENT
                    ? lastAppliedLabelFillColor
                    : getSecondaryContainerColor();
            applyLabelFillColor(initialFill);

            int initialStroke = lastAppliedLabelStrokeColor != Color.TRANSPARENT
                    ? lastAppliedLabelStrokeColor
                    : getOutlineColor();
            applyLabelStrokeColor(initialStroke);

            int initialSecondary = lastAppliedSecondaryColor != Color.TRANSPARENT
                    ? lastAppliedSecondaryColor
                    : getSecondaryColor();
            applySecondaryColor(initialSecondary);
        } catch (Throwable t) {
            Log.e(TAG, "attachLabelLayout failed", t);
        }
    }

    public void attachEmoDroid(@NonNull LottieAnimationView view) {
        try {
            this.emoDroid = view;
            LottieThemeEngine.Roles initial = lastAppliedLottieRoles != null
                    ? lastAppliedLottieRoles
                    : LottieThemeEngine.readStaticRoles(context);
            applyLottieRoles(initial);
        } catch (Throwable t) {
            Log.e(TAG, "attachEmoDroid failed", t);
        }
    }

    /**
     * Rings and glow both follow the indicator color. The glow is drawn
     * at low alpha by {@link CookieRippleView} as an M3 state layer, so
     * its lightness stays consistent across installer hues.
     */
    public void attachRippleView(@NonNull CookieRippleView view) {
        try {
            this.rippleView = view;

            int initial = lastAppliedIndicatorColor != Color.TRANSPARENT
                    ? lastAppliedIndicatorColor
                    : getPrimaryColor();
            view.setRingColor(initial);
            view.setGlowColor(initial);
        } catch (Throwable t) {
            Log.e(TAG, "attachRippleView failed", t);
        }
    }

    // ============================================================
    // Initial configuration
    // ============================================================

    private void configureIndicator() {

        float density = context.getResources().getDisplayMetrics().density;

        indicator.setIndeterminate(false);
        indicator.setMin(0);
        indicator.setMax(PROGRESS_MAX);

        // Order matters: the thickness setter no longer updates the
        // corner radius, so the radius is set explicitly afterwards.
        int thicknessPx = Math.round(TRACK_THICKNESS_DP * density);
        indicator.setTrackThickness(thicknessPx);
        indicator.setTrackCornerRadius(thicknessPx / 2);
        indicator.setIndicatorTrackGapSize(Math.round(GAP_DP * density));
        indicator.setTrackStopIndicatorSize(Math.round(STOP_DP * density));

        // Material 3 Expressive wavy shape + wave animation.
        int wavelengthPx = Math.round(WAVELENGTH_DP * density);
        indicator.setWavelength(wavelengthPx);
        indicator.setWaveAmplitude(Math.round(WAVE_AMPLITUDE_DP * density));
        // One wavelength per second, matching Google's default behavior.
        indicator.setWaveSpeed(wavelengthPx);

        // By default the wave amplitude ramps DOWN between 90% and 100%
        // progress (waveAmplitudeRampProgressMax = 0.9), so a full bar
        // turns flat. Moving the ramp-down point to 1.0 keeps the full
        // wave (and its motion) all the way to 100%. The ramp-up at the
        // start (waveAmplitudeRampProgressMin = 0.1) is left at default so
        // tiny shares still render as clean flat pills.
        indicator.setWaveAmplitudeRampProgressMax(1.0f);

        indicator.setProgressCompat(0, false);

        // Re-apply the (pixel-based) minimum visible fill once the real
        // track width is known or changes (first layout, rotation, etc.).
        // Kept as a field so it can be removed in cleanup() -- otherwise it
        // pins this whole instance to the indicator view across config
        // changes.
        indicatorLayoutListener = new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(
                    View v, int left, int top, int right, int bottom,
                    int oldLeft, int oldTop, int oldRight, int oldBottom) {
                try {
                    if (destroyed || !hasData) return;
                    int newWidth = right - left;
                    int oldWidth = oldRight - oldLeft;
                    if (newWidth == oldWidth || oldWidth == 0) return;
                    if (launchAnimator != null) return;
                    indicator.setProgressCompat(
                            toIndicatorProgress(
                                    currentSelectionCount(), currentTotal),
                            false);
                } catch (Throwable ignored) {}
            }
        };
        indicator.addOnLayoutChangeListener(indicatorLayoutListener);

        // Resolve the initial palette. If an installer is selected and its
        // source color is already cached (loadState() just populated it
        // from prefs), use the installer colors immediately. Otherwise fall
        // back to the total palette. This prevents the brown theme colors
        // from flashing on cold start when the last selection was an
        // installer whose color is already known.
        InstallerColors colors;
        boolean haveInstallerColors = false;

        if (!TOTAL_KEY.equals(selectedKey)) {
            Integer cached = getCachedSourceColor(selectedKey);
            if (cached != null && cached != Color.TRANSPARENT) {
                colors = createInstallerColors(cached);
                haveInstallerColors = true;
            } else {
                colors = createTotalColors();
            }
        } else {
            colors = createTotalColors();
        }

        if (TOTAL_KEY.equals(selectedKey) || haveInstallerColors) {
            applyAllRoles(colors);
        } else {
            // Installer selected but its color is not yet resolved: use the
            // total palette as the pending state and hide the indicator
            // fill so the bar doesn't show a coloured fill before the real
            // one arrives.
            applyIndicatorColor(Color.TRANSPARENT);
            applyTrackColor(colors.trackColor);
            applyOnIndicatorColor(colors.onIndicatorColor);
            applyBodySurfaceColor(colors.surfaceContainerLowColor);
            applyOutlineVariantColor(colors.outlineVariantColor);
            applyAppCountPillColor(colors.appCountPillColor);
            applyLabelFillColor(colors.labelFillColor);
            applyLabelStrokeColor(colors.labelStrokeColor);
            applySecondaryColor(colors.secondaryColor);
            applyLottieRoles(colors.lottieRoles);
        }
    }

    private void loadState() {
        if (prefs == null) return;

        try {
            String key = prefs.getString(KEY_SELECTED_INSTALLER, TOTAL_KEY);
            selectedKey = (key == null || key.isEmpty()) ? TOTAL_KEY : key;
        } catch (Throwable t) {
            Log.e(TAG, "Failed to read selected installer", t);
            selectedKey = TOTAL_KEY;
        }

        try {
            for (Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
                String preferenceKey = entry.getKey();
                if (preferenceKey == null) continue;
                if (!preferenceKey.startsWith(SOURCE_COLOR_PREFIX)) continue;
                Object value = entry.getValue();
                if (!(value instanceof Integer)) continue;

                String installerKey =
                        preferenceKey.substring(SOURCE_COLOR_PREFIX.length());
                synchronized (sourceColorCache) {
                    sourceColorCache.put(installerKey, (Integer) value);
                }
            }
        } catch (Throwable e) {
            Log.e(TAG, "Error loading source-color cache", e);
        }
    }

    // ============================================================
    // Public entry points
    // ============================================================

    public void setDistribution(
            int totalUserApps,
            @Nullable List<InstalledAppTracker.InstallerInfo> installerInfos) {

        final List<InstallerSnapshot> snapshots = new ArrayList<>();
        try {
            if (installerInfos != null) {
                for (InstalledAppTracker.InstallerInfo info : installerInfos) {
                    if (info == null) continue;
                    String key = info.getKey();
                    if (key == null) continue;
                    snapshots.add(new InstallerSnapshot(
                            key, info.getLabel(), info.getCount()));
                }
            }
        } catch (Throwable t) {
            Log.e(TAG, "Failed to snapshot installer infos", t);
            snapshots.clear();
        }

        final int total = Math.max(0, totalUserApps);

        try {
            if (Looper.myLooper() != Looper.getMainLooper()) {
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        try {
                            if (!destroyed) setDistributionOnMain(total, snapshots);
                        } catch (Throwable t) {
                            Log.e(TAG, "setDistributionOnMain post failed", t);
                            safeApplyTotalColors();
                        }
                    }
                });
            } else {
                setDistributionOnMain(total, snapshots);
            }
        } catch (Throwable t) {
            Log.e(TAG, "setDistribution failed", t);
        }
    }

    private void setDistributionOnMain(
            int totalUserApps,
            @NonNull List<InstallerSnapshot> snapshots) {

        try {
            currentTotal = Math.max(0, totalUserApps);
            hasData = true;

            int gen = generation.incrementAndGet();

            // The indicator max is fixed at PROGRESS_MAX, so there is no
            // per-distribution max to update here anymore.

            // New data invalidates any in-flight color resolution; clear
            // the guard so a fresh task can be scheduled for the same key.
            cancelBackgroundColorTask();
            resolvingKey = null;

            installedAppIndex = null;
            synchronized (failedCache) { failedCache.clear(); }
            currentAggregates.clear();

            for (InstallerSnapshot snapshot : snapshots) {
                if (snapshot == null) continue;
                String key = snapshot.key;
                if (key == null || key.isEmpty() || TOTAL_KEY.equals(key)) continue;
                int count = Math.max(0, snapshot.count);
                if (count <= 0) continue;

                String label = (snapshot.label == null || snapshot.label.isEmpty())
                        ? key : snapshot.label;

                InstallerAggregate aggregate = currentAggregates.get(key);
                if (aggregate == null) {
                    aggregate = new InstallerAggregate(key, label);
                    currentAggregates.put(key, aggregate);
                }
                aggregate.count += count;
            }

            long knownSum = 0;
            for (InstallerAggregate aggregate : currentAggregates.values()) {
                knownSum += aggregate.count;
            }

            if (currentTotal > knownSum) {
                int missing = currentTotal - (int) knownSum;
                InstallerAggregate unknownAggregate =
                        currentAggregates.get(UNKNOWN_KEY);
                if (unknownAggregate == null) {
                    unknownAggregate =
                            new InstallerAggregate(UNKNOWN_KEY, "Unknown");
                    currentAggregates.put(UNKNOWN_KEY, unknownAggregate);
                }
                unknownAggregate.count += missing;
            }

            if (!TOTAL_KEY.equals(selectedKey)
                    && !currentAggregates.containsKey(selectedKey)) {
                selectedKey = TOTAL_KEY;
                persistSelectedKey();
                cancelBackgroundColorTask();
                resolvingKey = null;
            }

            renderCurrentSelection(gen, false);

        } catch (Throwable t) {
            Log.e(TAG, "setDistributionOnMain failed", t);
            // Fall back to the static theme so the panel stays usable.
            try {
                selectedKey = TOTAL_KEY;
                safeApplyTotalColors();
            } catch (Throwable ignored) {}
        }
    }

    public void setSelectedInstaller(@Nullable String key) {
        try {
            final String safeKey =
                    (key == null || key.trim().isEmpty()) ? TOTAL_KEY : key;

            if (Looper.myLooper() != Looper.getMainLooper()) {
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        try {
                            if (!destroyed) setSelectedInstallerOnMain(safeKey);
                        } catch (Throwable t) {
                            Log.e(TAG, "setSelectedInstallerOnMain post failed", t);
                        }
                    }
                });
            } else {
                setSelectedInstallerOnMain(safeKey);
            }
        } catch (Throwable t) {
            Log.e(TAG, "setSelectedInstaller failed", t);
        }
    }

    private void setSelectedInstallerOnMain(@NonNull String newKey) {
        try {
            // Nothing to do when the selection is unchanged. This avoids
            // cancelling an in-flight bg color task and re-triggering a
            // full crossfade (and possibly the launch animation) when the
            // adapter re-dispatches the same row.
            if (newKey.equals(selectedKey)) return;

            selectedKey = newKey;
            persistSelectedKey();

            int gen = generation.incrementAndGet();

            cancelBackgroundColorTask();
            resolvingKey = null;
            cancelLaunchAnimation();

            if (!hasData) return;
            renderCurrentSelection(gen, true);
        } catch (Throwable t) {
            Log.e(TAG, "setSelectedInstallerOnMain failed", t);
        }
    }

    public void refreshThemeColors() {
        try {
            if (Looper.myLooper() != Looper.getMainLooper()) {
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        refreshThemeColors();
                    }
                });
                return;
            }
            if (destroyed) return;
            int gen = generation.incrementAndGet();
            cancelBackgroundColorTask();
            resolvingKey = null;
            renderCurrentSelection(gen, true);
        } catch (Throwable t) {
            Log.e(TAG, "refreshThemeColors failed", t);
        }
    }

    public void clear() {
        try {
            if (Looper.myLooper() != Looper.getMainLooper()) {
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        try {
                            if (!destroyed) clearOnMain();
                        } catch (Throwable t) {
                            Log.e(TAG, "clearOnMain post failed", t);
                        }
                    }
                });
            } else {
                clearOnMain();
            }
        } catch (Throwable t) {
            Log.e(TAG, "clear failed", t);
        }
    }

    private void clearOnMain() {
        try {
            generation.incrementAndGet();
            cancelBackgroundColorTask();
            cancelLaunchAnimation();
            cancelColorAnims();

            currentTotal = 0;
            currentAggregates.clear();
            hasData = false;
            launchStarted = false;
            resolvingKey = null;
            selectedKey = TOTAL_KEY;
            persistSelectedKey();

            applyAllRoles(createTotalColors());

            try { indicator.setProgressCompat(0, false); } catch (Throwable ignored) {}
        } catch (Throwable t) {
            Log.e(TAG, "clearOnMain failed", t);
        }
    }

    // ============================================================
    // Rendering
    // ============================================================

    private void renderCurrentSelection(int gen, boolean userInitiated) {

        try {
            if (TOTAL_KEY.equals(selectedKey)) {
                cancelBackgroundColorTask();
                resolvingKey = null;
                InstallerColors colors = createTotalColors();
                int totalProgress =
                        computeVisibleProgress(currentTotal, currentTotal);

                if (!launchStarted && !userInitiated) {
                    applyAllRoles(colors);
                    startLaunchAnimation(totalProgress);
                    return;
                }
                animateToState(totalProgress, colors, userInitiated);
                return;
            }

            InstallerAggregate aggregate = currentAggregates.get(selectedKey);
            if (aggregate == null) {
                if (!hasData) return;
                selectedKey = TOTAL_KEY;
                persistSelectedKey();
                renderCurrentSelection(gen, userInitiated);
                return;
            }

            int progress = computeVisibleProgress(aggregate.count, currentTotal);

            if (isUnknownInstaller(aggregate)) {
                cancelBackgroundColorTask();
                resolvingKey = null;
                InstallerColors colors = createInstallerColors(UNKNOWN_SEED_COLOR);

                if (!launchStarted && !userInitiated) {
                    applyAllRoles(colors);
                    startLaunchAnimation(progress);
                    return;
                }
                animateToState(progress, colors, userInitiated);
                return;
            }

            Integer sourceColor = getCachedSourceColor(aggregate.key);
            if (sourceColor != null && sourceColor != Color.TRANSPARENT) {
                cancelBackgroundColorTask();
                resolvingKey = null;
                InstallerColors colors = createInstallerColors(sourceColor);

                if (!launchStarted && !userInitiated) {
                    applyAllRoles(colors);
                    startLaunchAnimation(progress);
                    return;
                }
                animateToState(progress, colors, userInitiated);
                return;
            }

            // ── FIX: pending state. The colors for this installer are not
            // cached yet. Do NOT touch the current visual state: keep
            // whatever is displayed, animate only the progress bar, and
            // let the background task's callback crossfade from the
            // current colors to the new installer's palette when it is
            // ready. Stomping the colors with the total palette plus a
            // transparent indicator was the source of the visible flicker
            // on the first tap of any installer whose colors weren't
            // yet cached.
            try {
                indicator.setProgressCompat(progress, true);
            } catch (Throwable ignored) {}

            if (!aggregate.key.equals(resolvingKey)) {
                startBackgroundColorResolution(gen, aggregate, progress, !launchStarted);
            }

        } catch (Throwable t) {
            Log.e(TAG, "renderCurrentSelection failed", t);
            // Fall back to the static theme.
            try {
                selectedKey = TOTAL_KEY;
                safeApplyTotalColors();
            } catch (Throwable ignored) {}
        }
    }

    /**
     * Converts an app count into indicator progress on the fixed
     * PROGRESS_MAX scale. See toIndicatorProgress for the small-share rule.
     */
    private int computeVisibleProgress(int count, int total) {
        return toIndicatorProgress(count, total);
    }

    /**
     * Maps count/total onto 0..PROGRESS_MAX. Any non-zero share is raised to
     * at least the track thickness in pixels (Google's own indicators round
     * small non-zero values up to the stroke width), which prevents the two
     * rounded end caps from overlapping into a leaf shape.
     */
    private int toIndicatorProgress(int count, int total) {
        if (total <= 0 || count <= 0) return 0;
        int minVisible = minVisibleProgress();
        int maxVisible = Math.max(minVisible, maxVisibleProgress());

        // A full bar stops short of the end too, leaving the gap, a little
        // visible track and the stop dot.
        if (count >= total) return maxVisible;

        int scaled = Math.round((count / (float) total) * PROGRESS_MAX);
        int result = Math.max(scaled, minVisible);
        return Math.min(maxVisible, result);
    }

    /** Track width in pixels (estimated until the first layout pass). */
    private int trackWidthPx() {
        int width = indicator.getWidth()
                - indicator.getPaddingLeft()
                - indicator.getPaddingRight();
        if (width <= 0) {
            // Not laid out yet: estimate; corrected by the layout listener.
            width = Math.round(
                    context.getResources().getDisplayMetrics().widthPixels
                            * 0.8f);
        }
        return Math.max(1, width);
    }

    /** Smallest non-zero progress, in PROGRESS_MAX units. */
    private int minVisibleProgress() {
        float minPx = indicator.getTrackThickness()
                * MIN_VISIBLE_THICKNESS_MULTIPLIER;
        return Math.round((minPx / trackWidthPx()) * PROGRESS_MAX);
    }

    /**
     * Largest progress, in PROGRESS_MAX units. Reserves END_GAP_DP of the
     * track so the fill never touches the end.
     */
    private int maxVisibleProgress() {
        float density = context.getResources().getDisplayMetrics().density;
        float reservePx = END_GAP_DP * density;
        return PROGRESS_MAX
                - Math.round((reservePx / trackWidthPx()) * PROGRESS_MAX);
    }

    /** App count of whatever is currently selected (total or installer). */
    private int currentSelectionCount() {
        if (TOTAL_KEY.equals(selectedKey)) return currentTotal;
        InstallerAggregate aggregate = currentAggregates.get(selectedKey);
        return aggregate == null ? 0 : aggregate.count;
    }

    private void startBackgroundColorResolution(
            final int expectedGeneration,
            @NonNull final InstallerAggregate aggregate,
            final int progress,
            final boolean startLaunchWhenReady) {

        cancelBackgroundColorTask();
        resolvingKey = aggregate.key;

        final String key = aggregate.key;
        final String label = aggregate.label;

        try {
            activeColorTask = bgExecutor.submit(new Runnable() {
                @Override public void run() {

                    int sourceColor = Color.TRANSPARENT;

                    try {
                        if (destroyed
                                || generation.get() != expectedGeneration) {
                            return;
                        }

                        PackageManager packageManager =
                                context.getPackageManager();
                        Drawable icon = resolveInstallerIcon(
                                key, label, packageManager);

                        if (destroyed
                                || generation.get() != expectedGeneration) {
                            return;
                        }

                        if (icon != null) {
                            sourceColor =
                                    ArtworkColorHelper.extractSourceColor(icon);
                        }

                    } catch (Throwable t) {
                        Log.e(TAG, "bg color resolution failed", t);
                        sourceColor = Color.TRANSPARENT;
                    }

                    final int result = sourceColor;

                    try {
                        mainHandler.post(new Runnable() {
                            @Override public void run() {
                                try {
                                    if (destroyed) return;

                                    // If the request is stale (generation
                                    // bumped, or selection changed), clear
                                    // the resolving guard when it still
                                    // refers to this key so a future
                                    // render can schedule a fresh task.
                                    if (generation.get() != expectedGeneration
                                            || !key.equals(selectedKey)) {
                                        if (key.equals(resolvingKey)) {
                                            resolvingKey = null;
                                        }
                                        return;
                                    }

                                    resolvingKey = null;

                                    InstallerColors colors =
                                            (result == Color.TRANSPARENT)
                                                    ? createTotalColors()
                                                    : createInstallerColors(result);

                                    if (result != Color.TRANSPARENT) {
                                        cacheSourceColor(key, result);
                                    }

                                    int actualProgress =
                                            computeVisibleProgress(
                                                    aggregate.count, currentTotal);

                                    if (!launchStarted && startLaunchWhenReady) {
                                        applyAllRoles(colors);
                                        startLaunchAnimation(actualProgress);
                                    } else {
                                        animateColorsOnly(colors);
                                        try {
                                            indicator.setProgressCompat(
                                                    actualProgress, true);
                                        } catch (Throwable e) {
                                            Log.e(TAG,
                                                    "Progress animation error", e);
                                        }
                                    }
                                } catch (Throwable t) {
                                    Log.e(TAG,
                                            "main color update failed", t);
                                    safeApplyTotalColors();
                                }
                            }
                        });
                    } catch (Throwable t) {
                        Log.e(TAG, "failed to post color update", t);
                    }
                }
            });
        } catch (Throwable t) {
            Log.e(TAG, "failed to submit color task", t);
            safeApplyTotalColors();
        }
    }

    // ============================================================
    // Color computation
    // ============================================================

    @NonNull
    private InstallerColors createTotalColors() {
        try {
            int pillColor = getPrimaryContainerColor();
            int labelFill = getSecondaryContainerColor();
            int labelStroke = getOutlineColor();

            LottieThemeEngine.Roles lottie = safeStaticLottieRoles();

            return new InstallerColors(
                    getPrimaryColor(),
                    getTotalTrackColor(),
                    getOnPrimaryColor(),
                    getSurfaceContainerLowColor(),
                    getOutlineVariantColor(),
                    pillColor,
                    labelFill,
                    labelStroke,
                    getSecondaryColor(),
                    lottie
            );
        } catch (Throwable t) {
            Log.e(TAG, "createTotalColors failed", t);
            return createLastResortColors();
        }
    }

    @NonNull
    private InstallerColors createLastResortColors() {
        boolean dark = safeIsNightMode();

        LottieThemeEngine.Roles lottie;
        try {
            lottie = LottieThemeEngine.readStaticRoles(context);
        } catch (Throwable t) {
            lottie = new LottieThemeEngine.Roles(
                    dark ? DEFAULT_PRIMARY_DARK : DEFAULT_PRIMARY_LIGHT,
                    dark ? DEFAULT_PRIMARY_CONTAINER_DARK
                         : DEFAULT_PRIMARY_CONTAINER_LIGHT,
                    dark ? DEFAULT_SECONDARY_DARK : DEFAULT_SECONDARY_LIGHT,
                    dark ? DEFAULT_ON_PRIMARY_DARK : DEFAULT_ON_PRIMARY_LIGHT,
                    dark ? DEFAULT_OUTLINE_DARK : DEFAULT_OUTLINE_LIGHT
            );
        }

        return new InstallerColors(
                dark ? DEFAULT_PRIMARY_DARK : DEFAULT_PRIMARY_LIGHT,
                dark ? DEFAULT_SURFACE_DARK : DEFAULT_SURFACE_LIGHT,
                dark ? DEFAULT_ON_PRIMARY_DARK : DEFAULT_ON_PRIMARY_LIGHT,
                dark ? DEFAULT_SURFACE_CONTAINER_LOW_DARK
                     : DEFAULT_SURFACE_CONTAINER_LOW_LIGHT,
                dark ? DEFAULT_OUTLINE_VARIANT_DARK
                     : DEFAULT_OUTLINE_VARIANT_LIGHT,
                dark ? DEFAULT_PRIMARY_CONTAINER_DARK
                     : DEFAULT_PRIMARY_CONTAINER_LIGHT,
                dark ? DEFAULT_SECONDARY_CONTAINER_DARK
                     : DEFAULT_SECONDARY_CONTAINER_LIGHT,
                dark ? DEFAULT_OUTLINE_DARK : DEFAULT_OUTLINE_LIGHT,
                dark ? DEFAULT_SECONDARY_DARK : DEFAULT_SECONDARY_LIGHT,
                lottie
        );
    }

    @NonNull
    private InstallerColors createInstallerColors(int sourceColor) {
        try {
            if (sourceColor == Color.TRANSPARENT) return createTotalColors();

            DynamicScheme scheme = null;
            try {
                scheme = ArtworkColorHelper.createScheme(context, sourceColor);
            } catch (Throwable t) {
                Log.e(TAG, "createScheme failed", t);
            }

            if (scheme == null) return createTotalColors();

            int indicatorColor = scheme.getPrimary();
            int onIndicatorColor = scheme.getOnPrimary();
            int secondaryContainer = scheme.getSecondaryContainer();
            int surfaceContainerLow = scheme.getSurfaceContainerLow();
            int outlineVariant = scheme.getOutlineVariant();
            int primaryContainer = scheme.getPrimaryContainer();
            int secondary = scheme.getSecondary();
            int outline = scheme.getOutline();

            LottieThemeEngine.Roles lottie;
            try {
                lottie = LottieThemeEngine.readSchemeRoles(context, scheme);
            } catch (Throwable t) {
                Log.e(TAG, "readSchemeRoles failed", t);
                lottie = safeStaticLottieRoles();
            }

            int trackColor =
                    ArtworkColorHelper.createTrackColor(context, secondaryContainer);

            if (indicatorColor == Color.TRANSPARENT) {
                throw new IllegalStateException("Scheme returned transparent primary");
            }
            if (trackColor == Color.TRANSPARENT) {
                throw new IllegalStateException("Scheme returned transparent container");
            }

            if (onIndicatorColor == Color.TRANSPARENT) onIndicatorColor = getOnPrimaryColor();
            if (surfaceContainerLow == Color.TRANSPARENT) surfaceContainerLow = getSurfaceContainerLowColor();
            if (outlineVariant == Color.TRANSPARENT) outlineVariant = getOutlineVariantColor();
            if (secondary == Color.TRANSPARENT) secondary = getSecondaryColor();
            if (primaryContainer == Color.TRANSPARENT) primaryContainer = getPrimaryContainerColor();
            if (outline == Color.TRANSPARENT) outline = getOutlineColor();

            return new InstallerColors(
                    indicatorColor,
                    trackColor,
                    onIndicatorColor,
                    surfaceContainerLow,
                    outlineVariant,
                    primaryContainer,
                    secondaryContainer,
                    outline,
                    secondary,
                    lottie
            );

        } catch (Throwable e) {
            Log.e(TAG, "Scheme color generation failed", e);

            try {
                int fallbackSC = safeThemeColor(
                        com.google.android.material.R.attr.colorSecondaryContainer,
                        getTotalTrackColor());

                return new InstallerColors(
                        getPrimaryColor(),
                        ArtworkColorHelper.createTrackColor(context, fallbackSC),
                        getOnPrimaryColor(),
                        getSurfaceContainerLowColor(),
                        getOutlineVariantColor(),
                        getPrimaryContainerColor(),
                        fallbackSC,
                        getOutlineColor(),
                        getSecondaryColor(),
                        safeStaticLottieRoles()
                );
            } catch (Throwable fallbackError) {
                Log.e(TAG, "Theme fallback failed", fallbackError);
                return createTotalColors();
            }
        }
    }

    // ============================================================
    // Icon resolution
    // ============================================================

    @Nullable
    private Drawable resolveInstallerIcon(
            @NonNull String key,
            @NonNull String label,
            @NonNull PackageManager packageManager) {

        try {
            // ── FIX: bail before any PackageManager work for Unknown keys
            // or Unknown-style labels. This is the guard that keeps the
            // expensive "index every installed app's label" fallback from
            // ever running for the Unknown bucket.
            if (isUnknownInstallerKey(key)) return null;

            String normalizedLabel = normalizeKey(label);
            if ("unknown".equals(normalizedLabel)
                    || normalizedLabel.contains("sideload")) {
                return null;
            }

            synchronized (failedCache) {
                if (Boolean.TRUE.equals(failedCache.get(key))) return null;
            }

            synchronized (packageCache) {
                String packageName = packageCache.get(key);
                if (packageName != null) {
                    try {
                        return safeCopyDrawable(
                                packageManager.getApplicationIcon(packageName));
                    } catch (Throwable ignored) {}
                }
            }

            try {
                Drawable icon = packageManager.getApplicationIcon(key);
                synchronized (packageCache) { packageCache.put(key, key); }
                return safeCopyDrawable(icon);
            } catch (Throwable ignored) {}

            Map<String, String> index = installedAppIndex;
            if (index == null) {
                synchronized (this) {
                    index = installedAppIndex;
                    if (index == null) {
                        index = new HashMap<>();
                        try {
                            List<ApplicationInfo> applications =
                                    packageManager.getInstalledApplications(0);
                            for (ApplicationInfo appInfo : applications) {
                                if (appInfo == null || appInfo.packageName == null) continue;
                                try {
                                    CharSequence appLabel =
                                            packageManager.getApplicationLabel(appInfo);
                                    if (appLabel == null) continue;
                                    String normalized = normalizeKey(appLabel.toString());
                                    if (!normalized.isEmpty()
                                            && !index.containsKey(normalized)) {
                                        index.put(normalized, appInfo.packageName);
                                    }
                                } catch (Throwable ignored) {}
                            }
                        } catch (Throwable e) {
                            Log.e(TAG, "Failed to index applications", e);
                        }
                        installedAppIndex = index;
                    }
                }
            }

            String candidate = index.get(normalizeKey(key));
            if (candidate == null) candidate = index.get(normalizeKey(label));

            if (candidate != null) {
                try {
                    Drawable icon = packageManager.getApplicationIcon(candidate);
                    synchronized (packageCache) { packageCache.put(key, candidate); }
                    return safeCopyDrawable(icon);
                } catch (Throwable ignored) {}
            }

            synchronized (failedCache) { failedCache.put(key, true); }
            return null;

        } catch (Throwable t) {
            Log.e(TAG, "resolveInstallerIcon failed", t);
            return null;
        }
    }

    @NonNull
    private Drawable safeCopyDrawable(@NonNull Drawable original) {
        try {
            Drawable.ConstantState state = original.getConstantState();
            if (state != null) {
                Drawable copy = state.newDrawable().mutate();
                if (copy != null) return copy;
            }
        } catch (Throwable ignored) {}
        try {
            return original.mutate();
        } catch (Throwable ignored) {
            return original;
        }
    }

    // ============================================================
    // Animation
    // ============================================================

    private void animateToState(
            int targetProgress,
            @NonNull InstallerColors target,
            boolean animate) {

        try {
            // Always cancel any in-flight launch animation: otherwise its
            // update listener keeps overwriting the progress we set below.
            cancelLaunchAnimation();

            if (!animate) {
                applyAllRoles(target);
                try { indicator.setProgressCompat(targetProgress, false); }
                catch (Throwable ignored) {}
                return;
            }

            animateColorsOnly(target);

            try { indicator.setProgressCompat(targetProgress, true); }
            catch (Throwable e) { Log.e(TAG, "Progress animation failed", e); }

        } catch (Throwable t) {
            Log.e(TAG, "animateToState failed", t);
            safeApplyTotalColors();
        }
    }

    private void animateColorsOnly(@NonNull InstallerColors target) {
        try {
            cancelColorAnims();

            indicatorColorAnim = buildAnimator(
                    getCurrentIndicatorColor(), target.indicatorColor,
                    new ColorSink() { @Override public void accept(int c) {
                        applyIndicatorColor(c); } });

            trackColorAnim = buildAnimator(
                    getCurrentTrackColor(), target.trackColor,
                    new ColorSink() { @Override public void accept(int c) {
                        applyTrackColor(c); } });

            textColorAnim = buildAnimator(
                    getCurrentOnIndicatorColor(), target.onIndicatorColor,
                    new ColorSink() { @Override public void accept(int c) {
                        applyOnIndicatorColor(c); } });

            surfaceColorAnim = buildAnimator(
                    getCurrentSurfaceColor(), target.surfaceContainerLowColor,
                    new ColorSink() { @Override public void accept(int c) {
                        applyBodySurfaceColor(c); } });

            outlineColorAnim = buildAnimator(
                    getCurrentOutlineColor(), target.outlineVariantColor,
                    new ColorSink() { @Override public void accept(int c) {
                        applyOutlineVariantColor(c); } });

            pillColorAnim = buildAnimator(
                    getCurrentPillColor(), target.appCountPillColor,
                    new ColorSink() { @Override public void accept(int c) {
                        applyAppCountPillColor(c); } });

            labelFillColorAnim = buildAnimator(
                    getCurrentLabelFillColor(), target.labelFillColor,
                    new ColorSink() { @Override public void accept(int c) {
                        applyLabelFillColor(c); } });

            labelStrokeColorAnim = buildAnimator(
                    getCurrentLabelStrokeColor(), target.labelStrokeColor,
                    new ColorSink() { @Override public void accept(int c) {
                        applyLabelStrokeColor(c); } });

            secondaryColorAnim = buildAnimator(
                    getCurrentSecondaryColor(), target.secondaryColor,
                    new ColorSink() { @Override public void accept(int c) {
                        applySecondaryColor(c); } });

            lottieColorAnim = buildLottieAnimator(
                    getCurrentLottieRoles(), target.lottieRoles);

        } catch (Throwable t) {
            Log.e(TAG, "animateColorsOnly failed", t);
        }
    }

    private interface ColorSink {
        void accept(int color);
    }

    @Nullable
    private ValueAnimator buildAnimator(
            int from, int to, @NonNull final ColorSink sink) {

        try {
            final ValueAnimator animator =
                    ValueAnimator.ofObject(new ArgbEvaluator(), from, to);
            animator.setDuration(COLOR_ANIM_MS);
            animator.setInterpolator(new DecelerateInterpolator(1.2f));

            animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) {
                    try { sink.accept((Integer) a.getAnimatedValue()); }
                    catch (Throwable ignored) {}
                }
            });

            animator.start();
            return animator;
        } catch (Throwable t) {
            Log.e(TAG, "buildAnimator failed", t);
            return null;
        }
    }

    @Nullable
    private ValueAnimator buildLottieAnimator(
            @NonNull final LottieThemeEngine.Roles from,
            @NonNull final LottieThemeEngine.Roles to) {

        try {
            ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
            animator.setDuration(COLOR_ANIM_MS);
            animator.setInterpolator(new DecelerateInterpolator(1.2f));

            animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) {
                    try {
                        float t = (Float) a.getAnimatedValue();
                        applyLottieRoles(new LottieThemeEngine.Roles(
                                ColorUtils.blendARGB(from.head, to.head, t),
                                ColorUtils.blendARGB(from.headAccent, to.headAccent, t),
                                ColorUtils.blendARGB(from.secondary, to.secondary, t),
                                ColorUtils.blendARGB(from.eyes, to.eyes, t),
                                ColorUtils.blendARGB(from.outline, to.outline, t)
                        ));
                    } catch (Throwable ignored) {}
                }
            });

            animator.start();
            return animator;
        } catch (Throwable t) {
            Log.e(TAG, "buildLottieAnimator failed", t);
            return null;
        }
    }

    // ============================================================
    // Apply methods
    // ============================================================

    private void applyAllRoles(@NonNull InstallerColors colors) {
        applyIndicatorColor(colors.indicatorColor);
        applyTrackColor(colors.trackColor);
        applyOnIndicatorColor(colors.onIndicatorColor);
        applyBodySurfaceColor(colors.surfaceContainerLowColor);
        applyOutlineVariantColor(colors.outlineVariantColor);
        applyAppCountPillColor(colors.appCountPillColor);
        applyLabelFillColor(colors.labelFillColor);
        applyLabelStrokeColor(colors.labelStrokeColor);
        applySecondaryColor(colors.secondaryColor);
        applyLottieRoles(colors.lottieRoles);
    }

    private void safeApplyTotalColors() {
        try {
            applyAllRoles(createTotalColors());
        } catch (Throwable t) {
            Log.e(TAG, "safeApplyTotalColors failed", t);
            try {
                applyAllRoles(createLastResortColors());
            } catch (Throwable ignored) {}
        }
    }

    private void applyIndicatorColor(int color) {
        lastAppliedIndicatorColor = color;
        try { indicator.setIndicatorColor(color); }
        catch (Throwable e) { Log.e(TAG, "Failed indicator color", e); }
        applyAppCountFillColor(color);
        applyAppCountIconTint(color);
        applyRippleColor(color);
        applyRippleGlowColor(color);
    }

    /** Ring color (follows the indicator color). */
    private void applyRippleColor(int color) {
        if (rippleView == null) return;
        try { rippleView.setRingColor(color); }
        catch (Throwable e) { Log.e(TAG, "Failed ripple color", e); }
    }

    /** Glow color (follows the indicator color). */
    private void applyRippleGlowColor(int color) {
        if (rippleView == null) return;
        try { rippleView.setGlowColor(color); }
        catch (Throwable e) { Log.e(TAG, "Failed ripple glow color", e); }
    }

    private void applyAppCountFillColor(int color) {
        if (appCountBackground == null) return;
        try { appCountBackground.setFillColor(color); }
        catch (Throwable e) { Log.e(TAG, "Failed appCountTextLayout fill", e); }
    }

    private void applyAppCountIconTint(int color) {
        if (appCountIcon == null) return;
        try { appCountIcon.setImageTintList(ColorStateList.valueOf(color)); }
        catch (Throwable e) { Log.e(TAG, "Failed appCountIcon tint", e); }
    }

    private void applyTrackColor(int color) {
        try { indicator.setTrackColor(color); }
        catch (Throwable e) { Log.e(TAG, "Failed track color", e); }
    }

    private void applyOnIndicatorColor(int color) {
        lastAppliedOnIndicatorColor = color;
        if (appCountText == null) return;
        try { appCountText.setTextColor(color); }
        catch (Throwable e) { Log.e(TAG, "Failed appCountText color", e); }
    }

    private void applyBodySurfaceColor(int color) {
        lastAppliedSurfaceColor = color;
        if (bodyOutlineDrawable == null) return;
        try {
            bodyOutlineDrawable.setFillColor(ColorStateList.valueOf(color));
        } catch (Throwable e) { Log.e(TAG, "Failed bodyOutline fill", e); }
    }

    private void applyOutlineVariantColor(int color) {
        lastAppliedOutlineColor = color;

        if (bodyOutlineDrawable != null) {
            try {
                bodyOutlineDrawable.setStrokeColor(
                        ColorStateList.valueOf(color)
                );
            } catch (Throwable e) {
                Log.e(TAG, "Failed bodyOutline stroke", e);
            }
        }

        if (borderDrawables.isEmpty()) return;

        int lightBorderColor;
        try {
            lightBorderColor = ColorUtils.blendARGB(
                    color,
                    getSurfaceContainerLowColor(),
                    BORDER_LIGHTEN_AMOUNT
            );
        } catch (Throwable t) {
            lightBorderColor = color;
        }

        final ColorStateList borderCsl =
                ColorStateList.valueOf(lightBorderColor);

        for (int i = 0; i < borderDrawables.size(); i++) {
            RoundedShapeDrawable drawable = borderDrawables.get(i);
            if (drawable == null) continue;
            try {
                drawable.setFillColor(borderCsl);
            } catch (Throwable e) {
                Log.e(TAG, "Failed border fill", e);
            }
        }
    }

    private void applyAppCountPillColor(int color) {
        lastAppliedPillColor = color;
        if (appCountPillDrawable == null) return;
        try {
            appCountPillDrawable.setFillColor(ColorStateList.valueOf(color));
        } catch (Throwable e) { Log.e(TAG, "Failed pill fill", e); }
    }

    private void applyLabelFillColor(int color) {
        lastAppliedLabelFillColor = color;
        if (labelLayoutDrawable == null) return;
        try {
            labelLayoutDrawable.setFillColor(ColorStateList.valueOf(color));
        } catch (Throwable e) { Log.e(TAG, "Failed label fill", e); }
    }

    private void applyLabelStrokeColor(int color) {
        lastAppliedLabelStrokeColor = color;
        if (labelLayoutDrawable == null) return;
        try {
            labelLayoutDrawable.setStrokeColor(ColorStateList.valueOf(color));
        } catch (Throwable e) { Log.e(TAG, "Failed label stroke", e); }
    }

    private void applySecondaryColor(int color) {
        lastAppliedSecondaryColor = color;
        if (labelText != null) {
            try { labelText.setTextColor(color); }
            catch (Throwable e) { Log.e(TAG, "Failed label text", e); }
        }
        if (labelIcon != null) {
            try { labelIcon.setImageTintList(ColorStateList.valueOf(color)); }
            catch (Throwable e) { Log.e(TAG, "Failed label icon tint", e); }
        }
    }

    private void applyLottieRoles(@NonNull LottieThemeEngine.Roles roles) {
        lastAppliedLottieRoles = roles;
        if (emoDroid == null) return;
        try { LottieThemeEngine.applyRoles(emoDroid, roles); }
        catch (Throwable e) { Log.e(TAG, "Failed Lottie roles", e); }
    }

    // ============================================================
    // Current-value getters
    // ============================================================

    private int getCurrentIndicatorColor() {
        try {
            int[] colors = indicator.getIndicatorColor();
            if (colors != null && colors.length > 0) return colors[0];
        } catch (Throwable ignored) {}
        return lastAppliedIndicatorColor != Color.TRANSPARENT
                ? lastAppliedIndicatorColor : getPrimaryColor();
    }

    private int getCurrentTrackColor() {
        try { return indicator.getTrackColor(); }
        catch (Throwable e) { return getTotalTrackColor(); }
    }

    private int getCurrentOnIndicatorColor() {
        return lastAppliedOnIndicatorColor != Color.TRANSPARENT
                ? lastAppliedOnIndicatorColor : getOnPrimaryColor();
    }

    private int getCurrentSurfaceColor() {
        return lastAppliedSurfaceColor != Color.TRANSPARENT
                ? lastAppliedSurfaceColor : getSurfaceContainerLowColor();
    }

    private int getCurrentOutlineColor() {
        return lastAppliedOutlineColor != Color.TRANSPARENT
                ? lastAppliedOutlineColor : getOutlineVariantColor();
    }

    private int getCurrentPillColor() {
        return lastAppliedPillColor != Color.TRANSPARENT
                ? lastAppliedPillColor : getPrimaryContainerColor();
    }

    private int getCurrentLabelFillColor() {
        return lastAppliedLabelFillColor != Color.TRANSPARENT
                ? lastAppliedLabelFillColor : getSecondaryContainerColor();
    }

    private int getCurrentLabelStrokeColor() {
        return lastAppliedLabelStrokeColor != Color.TRANSPARENT
                ? lastAppliedLabelStrokeColor : getOutlineColor();
    }

    private int getCurrentSecondaryColor() {
        return lastAppliedSecondaryColor != Color.TRANSPARENT
                ? lastAppliedSecondaryColor : getSecondaryColor();
    }

    @NonNull
    private LottieThemeEngine.Roles getCurrentLottieRoles() {
        return lastAppliedLottieRoles != null
                ? lastAppliedLottieRoles
                : safeStaticLottieRoles();
    }

    @NonNull
    private LottieThemeEngine.Roles safeStaticLottieRoles() {
        try {
            return LottieThemeEngine.readStaticRoles(context);
        } catch (Throwable t) {
            Log.e(TAG, "readStaticRoles failed", t);
            boolean dark = safeIsNightMode();
            return new LottieThemeEngine.Roles(
                    dark ? DEFAULT_PRIMARY_DARK : DEFAULT_PRIMARY_LIGHT,
                    dark ? DEFAULT_PRIMARY_CONTAINER_DARK
                         : DEFAULT_PRIMARY_CONTAINER_LIGHT,
                    dark ? DEFAULT_SECONDARY_DARK : DEFAULT_SECONDARY_LIGHT,
                    dark ? DEFAULT_ON_PRIMARY_DARK : DEFAULT_ON_PRIMARY_LIGHT,
                    dark ? DEFAULT_OUTLINE_DARK : DEFAULT_OUTLINE_LIGHT
            );
        }
    }

    // ============================================================
    // Launch animation
    // ============================================================

    /**
     * The targetProgress argument is kept for call-site compatibility; the
     * real target is recomputed when the animation actually starts so the
     * minimum-visible-fill uses the measured track width.
     */
    private void startLaunchAnimation(int targetProgress) {

        if (destroyed || launchStarted) return;

        launchStarted = true;
        launchToken++;
        final int token = launchToken;
        cancelLaunchAnimatorOnly();

        try { indicator.setProgressCompat(0, false); } catch (Throwable ignored) {}

        try {
            indicator.post(new Runnable() {
                @Override public void run() {
                    try {
                        if (destroyed || token != launchToken) return;
                        if (!indicator.isAttachedToWindow()) return;

                        final int target = toIndicatorProgress(
                                currentSelectionCount(), currentTotal);

                        ValueAnimator animator =
                                ValueAnimator.ofInt(0, target);
                        animator.setDuration(LAUNCH_ANIM_MS);
                        animator.setInterpolator(
                                new DecelerateInterpolator(1.35f));

                        animator.addUpdateListener(
                                new ValueAnimator.AnimatorUpdateListener() {
                                    @Override public void onAnimationUpdate(
                                            ValueAnimator a) {
                                        if (destroyed) return;
                                        try {
                                            indicator.setProgressCompat(
                                                    (Integer) a.getAnimatedValue(),
                                                    false);
                                        } catch (Throwable ignored) {}
                                    }
                                });

                        animator.addListener(new AnimatorListenerAdapter() {
                            @Override public void onAnimationEnd(Animator a) {
                                launchAnimator = null;
                                if (!destroyed) {
                                    try {
                                        indicator.setProgressCompat(
                                                target, false);
                                    } catch (Throwable ignored) {}
                                }
                            }
                            @Override public void onAnimationCancel(Animator a) {
                                launchAnimator = null;
                            }
                        });

                        launchAnimator = animator;
                        animator.start();

                    } catch (Throwable t) {
                        Log.e(TAG, "launch animation failed", t);
                    }
                }
            });
        } catch (Throwable t) {
            Log.e(TAG, "failed to post launch animation", t);
        }
    }

    private void cancelLaunchAnimation() {
        launchToken++;
        cancelLaunchAnimatorOnly();
    }

    private void cancelLaunchAnimatorOnly() {
        try {
            if (launchAnimator != null) {
                launchAnimator.cancel();
                launchAnimator = null;
            }
        } catch (Throwable ignored) {}
    }

    private void cancelColorAnims() {
        try { if (indicatorColorAnim != null) { indicatorColorAnim.cancel(); indicatorColorAnim = null; } } catch (Throwable ignored) {}
        try { if (trackColorAnim != null) { trackColorAnim.cancel(); trackColorAnim = null; } } catch (Throwable ignored) {}
        try { if (textColorAnim != null) { textColorAnim.cancel(); textColorAnim = null; } } catch (Throwable ignored) {}
        try { if (surfaceColorAnim != null) { surfaceColorAnim.cancel(); surfaceColorAnim = null; } } catch (Throwable ignored) {}
        try { if (outlineColorAnim != null) { outlineColorAnim.cancel(); outlineColorAnim = null; } } catch (Throwable ignored) {}
        try { if (pillColorAnim != null) { pillColorAnim.cancel(); pillColorAnim = null; } } catch (Throwable ignored) {}
        try { if (labelFillColorAnim != null) { labelFillColorAnim.cancel(); labelFillColorAnim = null; } } catch (Throwable ignored) {}
        try { if (labelStrokeColorAnim != null) { labelStrokeColorAnim.cancel(); labelStrokeColorAnim = null; } } catch (Throwable ignored) {}
        try { if (secondaryColorAnim != null) { secondaryColorAnim.cancel(); secondaryColorAnim = null; } } catch (Throwable ignored) {}
        try { if (lottieColorAnim != null) { lottieColorAnim.cancel(); lottieColorAnim = null; } } catch (Throwable ignored) {}
    }

    private void cancelBackgroundColorTask() {
        try {
            if (activeColorTask != null) {
                activeColorTask.cancel(true);
                activeColorTask = null;
            }
        } catch (Throwable ignored) {}
    }

    // ============================================================
    // Static theme readers
    // ============================================================

    private int safeThemeColor(int attrResId, int fallback) {
        try {
            return MaterialColors.getColor(context, attrResId, fallback);
        } catch (Throwable t) {
            return fallback;
        }
    }

    private int getPrimaryColor() {
        int fallback = safeIsNightMode()
                ? DEFAULT_PRIMARY_DARK : DEFAULT_PRIMARY_LIGHT;
        return safeThemeColor(
                com.google.android.material.R.attr.colorPrimary, fallback);
    }

    private int getOnPrimaryColor() {
        int fallback = safeIsNightMode()
                ? DEFAULT_ON_PRIMARY_DARK : DEFAULT_ON_PRIMARY_LIGHT;
        return safeThemeColor(
                com.google.android.material.R.attr.colorOnPrimary, fallback);
    }

    private int getTotalTrackColor() {
        int fallback = safeIsNightMode()
                ? DEFAULT_SURFACE_DARK : DEFAULT_SURFACE_LIGHT;
        return safeThemeColor(
                com.google.android.material.R.attr.colorSurfaceContainerHighest,
                fallback);
    }

    private int getSurfaceContainerLowColor() {
        int fallback = safeIsNightMode()
                ? DEFAULT_SURFACE_CONTAINER_LOW_DARK
                : DEFAULT_SURFACE_CONTAINER_LOW_LIGHT;
        return safeThemeColor(
                com.google.android.material.R.attr.colorSurfaceContainerLow,
                fallback);
    }

    private int getOutlineVariantColor() {
        int fallback = safeIsNightMode()
                ? DEFAULT_OUTLINE_VARIANT_DARK : DEFAULT_OUTLINE_VARIANT_LIGHT;
        return safeThemeColor(
                com.google.android.material.R.attr.colorOutlineVariant,
                fallback);
    }

    private int getPrimaryContainerColor() {
        int fallback = safeIsNightMode()
                ? DEFAULT_PRIMARY_CONTAINER_DARK
                : DEFAULT_PRIMARY_CONTAINER_LIGHT;
        return safeThemeColor(
                com.google.android.material.R.attr.colorPrimaryContainer,
                fallback);
    }

    private int getSurfaceContainerColor() {
        int fallback = safeIsNightMode()
                ? DEFAULT_SURFACE_CONTAINER_DARK
                : DEFAULT_SURFACE_CONTAINER_LIGHT;
        return safeThemeColor(
                com.google.android.material.R.attr.colorSurfaceContainer,
                fallback);
    }

    private int getSurfaceColor() {
        int fallback = safeIsNightMode()
                ? DEFAULT_SURFACE_BG_DARK : DEFAULT_SURFACE_BG_LIGHT;
        return safeThemeColor(
                com.google.android.material.R.attr.colorSurface, fallback);
    }

    private int getSecondaryContainerColor() {
        return safeThemeColor(
                com.google.android.material.R.attr.colorSecondaryContainer,
                getTotalTrackColor());
    }

    private int getSecondaryColor() {
        int fallback = safeIsNightMode()
                ? DEFAULT_SECONDARY_DARK : DEFAULT_SECONDARY_LIGHT;
        return safeThemeColor(
                com.google.android.material.R.attr.colorSecondary, fallback);
    }

    private int getOutlineColor() {
        int fallback = safeIsNightMode()
                ? DEFAULT_OUTLINE_DARK : DEFAULT_OUTLINE_LIGHT;
        return safeThemeColor(
                com.google.android.material.R.attr.colorOutline, fallback);
    }

    // ============================================================
    // Cache / persistence / teardown
    // ============================================================

    @Nullable
    private Integer getCachedSourceColor(@NonNull String key) {
        try {
            synchronized (sourceColorCache) { return sourceColorCache.get(key); }
        } catch (Throwable t) {
            return null;
        }
    }

    private void cacheSourceColor(@NonNull String key, int color) {
        if (color == Color.TRANSPARENT) return;
        try {
            synchronized (sourceColorCache) { sourceColorCache.put(key, color); }
        } catch (Throwable ignored) {}
        try {
            if (prefs != null) {
                prefs.edit().putInt(SOURCE_COLOR_PREFIX + key, color).apply();
            }
        } catch (Throwable e) {
            Log.e(TAG, "Failed to persist source color", e);
        }
    }

    private void persistSelectedKey() {
        try {
            if (prefs != null) {
                prefs.edit()
                        .putString(KEY_SELECTED_INSTALLER, selectedKey)
                        .apply();
            }
        } catch (Throwable e) {
            Log.e(TAG, "Failed to persist selected key", e);
        }
    }

    public void destroy() {
        // Atomic guard: two threads racing to destroy won't both pass the
        // early-return check and run cleanup twice.
        if (!destroyGuard.compareAndSet(false, true)) return;

        try {
            destroyed = true;
            generation.incrementAndGet();
            cancelBackgroundColorTask();
            bgExecutor.shutdownNow();
            mainHandler.removeCallbacksAndMessages(null);

            if (Looper.myLooper() == Looper.getMainLooper()) {
                cleanup();
            } else {
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        try {
                            cleanup();
                        } catch (Throwable t) {
                            Log.e(TAG, "cleanup post failed", t);
                        }
                    }
                });
            }
        } catch (Throwable t) {
            Log.e(TAG, "destroy failed", t);
        }
    }

    private void cleanup() {
        try { cancelLaunchAnimation(); } catch (Throwable ignored) {}
        try { cancelColorAnims(); } catch (Throwable ignored) {}

        // Detach the layout listener so it can't pin this instance to the
        // indicator view after the hosting Activity is gone.
        try {
            if (indicatorLayoutListener != null) {
                indicator.removeOnLayoutChangeListener(indicatorLayoutListener);
                indicatorLayoutListener = null;
            }
        } catch (Throwable ignored) {}

        activeColorTask = null;
        resolvingKey = null;

        try { currentAggregates.clear(); } catch (Throwable ignored) {}

        try { synchronized (sourceColorCache) { sourceColorCache.clear(); } }
        catch (Throwable ignored) {}
        try { synchronized (packageCache) { packageCache.clear(); } }
        catch (Throwable ignored) {}
        try { synchronized (failedCache) { failedCache.clear(); } }
        catch (Throwable ignored) {}

        installedAppIndex = null;

        bodyOutlineDrawable = null;
        try { borderDrawables.clear(); } catch (Throwable ignored) {}

        appCountPillDrawable = null;
        appCountIcon = null;
        labelLayoutDrawable = null;
        labelIcon = null;
        labelText = null;
        emoDroid = null;
        rippleView = null;
        lastAppliedLottieRoles = null;
    }

    // ============================================================
    // Helpers
    // ============================================================

    private boolean isUnknownInstaller(@NonNull InstallerAggregate aggregate) {
        if (isUnknownInstallerKey(aggregate.key)) return true;
        String normalized = normalizeKey(aggregate.label);
        return "unknown".equals(normalized) || normalized.contains("sideload");
    }

    // ── FIX: recognises the tracker's Unknown key in addition to this
    // class's own. This is the primary guard for the Unknown fast path;
    // the label check in isUnknownInstaller() is a secondary fallback
    // that must not be the sole decision-maker.
    private boolean isUnknownInstallerKey(@NonNull String key) {
        String normalized = normalizeKey(key);
        return UNKNOWN_KEY.equals(normalized)
                || "__unknown_installer__".equals(normalized)
                || "null".equals(normalized)
                || "android".equals(normalized)
                || "com.android.shell".equals(normalized);
    }

    @NonNull
    private String normalizeKey(@Nullable String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }

    private boolean isNightMode() {
        return safeIsNightMode();
    }

    private boolean safeIsNightMode() {
        try {
            int flags = context.getResources().getConfiguration().uiMode
                    & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
            return flags == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        } catch (Throwable t) {
            return false;
        }
    }

    // ============================================================
    // Bounded LRU caches
    // ============================================================

    private static final class BoundedColorCache
            extends LinkedHashMap<String, Integer> {
        BoundedColorCache() { super(96, 0.75f, true); }
        @Override protected boolean removeEldestEntry(Map.Entry entry) {
            return size() > 64;
        }
    }

    private static final class BoundedPackageCache
            extends LinkedHashMap<String, String> {
        BoundedPackageCache() { super(96, 0.75f, true); }
        @Override protected boolean removeEldestEntry(Map.Entry entry) {
            return size() > 64;
        }
    }

    private static final class BoundedFailedCache
            extends LinkedHashMap<String, Boolean> {
        BoundedFailedCache() { super(96, 0.75f, true); }
        @Override protected boolean removeEldestEntry(Map.Entry entry) {
            return size() > 64;
        }
    }

    // ============================================================
    // Value holders
    // ============================================================

    private static final class InstallerColors {

        final int indicatorColor;
        final int trackColor;
        final int onIndicatorColor;
        final int surfaceContainerLowColor;
        final int outlineVariantColor;
        final int appCountPillColor;
        final int labelFillColor;
        final int labelStrokeColor;
        final int secondaryColor;
        @NonNull final LottieThemeEngine.Roles lottieRoles;

        InstallerColors(
                int indicatorColor,
                int trackColor,
                int onIndicatorColor,
                int surfaceContainerLowColor,
                int outlineVariantColor,
                int appCountPillColor,
                int labelFillColor,
                int labelStrokeColor,
                int secondaryColor,
                @NonNull LottieThemeEngine.Roles lottieRoles) {

            this.indicatorColor = indicatorColor;
            this.trackColor = trackColor;
            this.onIndicatorColor = onIndicatorColor;
            this.surfaceContainerLowColor = surfaceContainerLowColor;
            this.outlineVariantColor = outlineVariantColor;
            this.appCountPillColor = appCountPillColor;
            this.labelFillColor = labelFillColor;
            this.labelStrokeColor = labelStrokeColor;
            this.secondaryColor = secondaryColor;
            this.lottieRoles = lottieRoles;
        }
    }

    private static final class InstallerSnapshot {
        final String key;
        final String label;
        final int count;

        InstallerSnapshot(@NonNull String key, @Nullable String label, int count) {
            this.key = key;
            this.label = label == null ? key : label;
            this.count = count;
        }
    }

    private static final class InstallerAggregate {
        final String key;
        final String label;
        int count;

        InstallerAggregate(@NonNull String key, @NonNull String label) {
            this.key = key;
            this.label = label;
            this.count = 0;
        }
    }
}