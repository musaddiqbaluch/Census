package com.musaddiqbaluch.census;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewOverlay;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowInsets;
import android.view.animation.DecelerateInterpolator;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.color.MaterialColors;
import com.google.android.material.tabs.TabLayout;

import java.util.WeakHashMap;

/**
 * Syncs a toolbar's background (and the system status bar, where
 * possible) with the horizontal scroll state of a TabLayout.
 *
 * Behaviour
 * ---------
 *   Not scrolled -> toolbar uses colorSurface.
 *   Scrolled     -> toolbar uses colorSurface tinted with colorPrimary
 *                   at the Material 3 tonal elevation of 3dp
 *                   (surfaceColorAtElevation(3dp) in Compose).
 *
 *   Status bar always matches the toolbar's current color, via either
 *   a decor-view overlay (edge-to-edge / Android 15+) or
 *   Window#setStatusBarColor (older releases). Both are updated in
 *   lockstep with the crossfade.
 *
 * Robustness
 * ----------
 *   - attach() / detach() are safe to call from any thread; the
 *     instance registry is synchronized.
 *   - Every listener and animator callback is wrapped in try/catch.
 *   - Every optional integration (window, decor view, overlay,
 *     RippleDrawable) degrades to a no-op if the platform refuses it.
 *   - Every Material color read falls back to hardcoded M3 defaults
 *     on failure.
 *   - The status-bar inset uses the modern WindowInsets API on
 *     Android 11+ (where getSystemWindowInsetTop() is deprecated and
 *     returns 0 in edge-to-edge mode).
 */
public final class MaterialToolbarScrollHelper {

    private static final String TAG = "ToolbarScrollHelper";

    private static final long COLOR_CHANGE_DURATION = 250L;
    private static final float DECELERATE_FACTOR = 1.4f;

    private static final float TONAL_ELEVATION_DP = 3f;
    private static final float RIPPLE_ALPHA = 0.12f;

    // Fallback M3 baseline, used if a theme attribute cannot be read.
    private static final int FALLBACK_SURFACE_LIGHT   = 0xFFFFFBFE;
    private static final int FALLBACK_SURFACE_DARK    = 0xFF1C1B1F;
    private static final int FALLBACK_PRIMARY_LIGHT   = 0xFF6750A4;
    private static final int FALLBACK_PRIMARY_DARK    = 0xFFD0BCFF;

    private static final WeakHashMap<View, MaterialToolbarScrollHelper>
            INSTANCES = new WeakHashMap<>();

    private final Context context;
    private final View view;
    private final TabLayout tabLayout;

    @Nullable
    private final Drawable originalBackground;

    @Nullable private Window window;
    @Nullable private View decorView;

    @Nullable private ColorDrawable statusBarScrim;

    private int originalStatusBarColor;

    @Nullable private GradientDrawable backgroundDrawable;
    @Nullable private RippleDrawable rippleDrawable;
    @Nullable private ValueAnimator colorAnimator;

    private int surfaceColor;
    private int surfaceTintColor;
    private int elevatedSurfaceColor;
    private int primaryColor;

    private int currentBackgroundColor;

    private boolean isScrolled;
    private boolean attached;

    private final ViewTreeObserver.OnScrollChangedListener
            scrollListener =
            new ViewTreeObserver.OnScrollChangedListener() {

                @Override
                public void onScrollChanged() {
                    try {
                        updateScrollState();
                    } catch (Throwable t) {
                        Log.e(TAG, "scrollListener failed", t);
                    }
                }
            };

    private final View.OnLayoutChangeListener
            decorLayoutListener =
            new View.OnLayoutChangeListener() {

                @Override
                public void onLayoutChange(
                        View v,
                        int left,
                        int top,
                        int right,
                        int bottom,
                        int oldLeft,
                        int oldTop,
                        int oldRight,
                        int oldBottom) {

                    try {
                        updateStatusBarScrimBounds();
                    } catch (Throwable t) {
                        Log.e(TAG, "decorLayoutListener failed", t);
                    }
                }
            };

    public MaterialToolbarScrollHelper(
            @NonNull Context context,
            @NonNull View view,
            @NonNull TabLayout tabLayout) {

        this.context = context;
        this.view = view;
        this.tabLayout = tabLayout;

        Drawable original = null;
        try {
            original = view.getBackground();
        } catch (Throwable t) {
            Log.e(TAG, "Failed to read original background", t);
        }
        this.originalBackground = original;
    }

    // ============================================================
    // Public API
    // ============================================================

    public void attach() {

        if (attached) {
            return;
        }

        try {
            attached = true;

            // ---- 1. Window & decor (optional) ----
            try {
                window = findWindow(context);
                if (window != null) {
                    try {
                        decorView = window.getDecorView();
                    } catch (Throwable t) {
                        Log.e(TAG, "getDecorView failed", t);
                        decorView = null;
                    }

                    try {
                        originalStatusBarColor = window.getStatusBarColor();
                    } catch (Throwable t) {
                        originalStatusBarColor = Color.TRANSPARENT;
                    }

                    if (decorView != null) {
                        try {
                            decorView.addOnLayoutChangeListener(
                                    decorLayoutListener);
                        } catch (Throwable t) {
                            Log.e(TAG, "addOnLayoutChangeListener failed", t);
                        }
                    }
                }
            } catch (Throwable t) {
                Log.e(TAG, "window lookup failed", t);
            }

            // ---- 2. Resolve Material 3 colors (with fallbacks) ----
            boolean dark = safeIsNightMode();

            surfaceColor = safeThemeColor(
                    com.google.android.material.R.attr.colorSurface,
                    dark ? FALLBACK_SURFACE_DARK : FALLBACK_SURFACE_LIGHT);

            // In the standard M3 scheme, surfaceTint == primary.
            surfaceTintColor = safeThemeColor(
                    com.google.android.material.R.attr.colorPrimary,
                    dark ? FALLBACK_PRIMARY_DARK : FALLBACK_PRIMARY_LIGHT);

            primaryColor = surfaceTintColor;

            // ---- 3. Tonal elevation ----
            try {
                elevatedSurfaceColor = surfaceColorAtElevation(
                        surfaceColor,
                        surfaceTintColor,
                        TONAL_ELEVATION_DP);
            } catch (Throwable t) {
                Log.e(TAG, "surfaceColorAtElevation failed", t);
                elevatedSurfaceColor = surfaceColor;
            }

            // ---- 4. Scroll state ----
            try {
                isScrolled = tabLayout.canScrollHorizontally(-1);
            } catch (Throwable t) {
                isScrolled = false;
            }

            currentBackgroundColor = getTargetColor();

            // ---- 5. Visuals ----
            try {
                createRippleBackground();
            } catch (Throwable t) {
                Log.e(TAG, "createRippleBackground failed", t);
            }

            try {
                createStatusBarScrim();
            } catch (Throwable t) {
                Log.e(TAG, "createStatusBarScrim failed", t);
            }

            try {
                installScrollListener();
            } catch (Throwable t) {
                Log.e(TAG, "installScrollListener failed", t);
            }

        } catch (Throwable t) {
            Log.e(TAG, "attach failed", t);
        }
    }

    public void detach() {

        if (!attached) {
            return;
        }

        try {
            attached = false;

            try { cancelColorAnimation(); }
            catch (Throwable ignored) {}

            // Remove the scroll listener.
            try {
                ViewTreeObserver observer = tabLayout.getViewTreeObserver();
                if (observer != null && observer.isAlive()) {
                    observer.removeOnScrollChangedListener(scrollListener);
                }
            } catch (Throwable t) {
                Log.e(TAG, "remove scroll listener failed", t);
            }

            // Remove the status-bar scrim.
            try { removeStatusBarScrim(); }
            catch (Throwable t) { Log.e(TAG, "removeStatusBarScrim failed", t); }

            // Remove the decor layout listener.
            if (decorView != null) {
                try {
                    decorView.removeOnLayoutChangeListener(decorLayoutListener);
                } catch (Throwable ignored) {}
            }

            // Restore the original toolbar background.
            try {
                view.setBackground(originalBackground);
            } catch (Throwable t) {
                Log.e(TAG, "restore background failed", t);
            }

            // Restore the original status-bar color.
            if (window != null) {
                try {
                    window.setStatusBarColor(originalStatusBarColor);
                } catch (Throwable ignored) {}
            }

            backgroundDrawable = null;
            rippleDrawable = null;
            window = null;
            decorView = null;

        } catch (Throwable t) {
            Log.e(TAG, "detach failed", t);
        }
    }

    // ============================================================
    // Background visuals
    // ============================================================

    private void createRippleBackground() {

        // Build the base drawable first.
        try {
            backgroundDrawable = new GradientDrawable();
            backgroundDrawable.setShape(GradientDrawable.RECTANGLE);
            backgroundDrawable.setColor(currentBackgroundColor);
        } catch (Throwable t) {
            Log.e(TAG, "GradientDrawable creation failed", t);
            backgroundDrawable = null;
            return;
        }

        // Then wrap in a RippleDrawable. If that fails, fall back to
        // applying the plain GradientDrawable.
        try {
            rippleDrawable = new RippleDrawable(
                    ColorStateList.valueOf(
                            createRippleColor(currentBackgroundColor)),
                    backgroundDrawable,
                    null);

            view.setBackground(rippleDrawable);

        } catch (Throwable t) {
            Log.e(TAG, "RippleDrawable creation failed, using plain "
                    + "GradientDrawable", t);
            rippleDrawable = null;

            try {
                view.setBackground(backgroundDrawable);
            } catch (Throwable t2) {
                Log.e(TAG, "view.setBackground failed", t2);
            }
        }
    }

    private int createRippleColor(int backgroundColor) {
        try {
            return MaterialColors.layer(
                    backgroundColor,
                    primaryColor,
                    RIPPLE_ALPHA);
        } catch (Throwable t) {
            // Fallback: translucent primary over background.
            int alpha = Math.round(RIPPLE_ALPHA * 255f);
            return Color.argb(
                    alpha,
                    Color.red(primaryColor),
                    Color.green(primaryColor),
                    Color.blue(primaryColor));
        }
    }

    private void installScrollListener() {

        try {
            ViewTreeObserver observer = tabLayout.getViewTreeObserver();
            if (observer == null) return;

            if (!observer.isAlive()) {
                // Try again on the next layout pass.
                tabLayout.post(new Runnable() {
                    @Override public void run() {
                        try {
                            if (!attached) return;
                            ViewTreeObserver o = tabLayout.getViewTreeObserver();
                            if (o != null && o.isAlive()) {
                                o.addOnScrollChangedListener(scrollListener);
                            }
                        } catch (Throwable t) {
                            Log.e(TAG, "deferred scroll listener failed", t);
                        }
                    }
                });
                return;
            }

            observer.addOnScrollChangedListener(scrollListener);

        } catch (Throwable t) {
            Log.e(TAG, "installScrollListener failed", t);
        }
    }

    // ============================================================
    // Scroll state
    // ============================================================

    private void updateScrollState() {

        if (!attached) {
            return;
        }

        try {
            boolean newState = tabLayout.canScrollHorizontally(-1);
            if (newState == isScrolled) {
                return;
            }
            isScrolled = newState;
            animateBackground();
        } catch (Throwable t) {
            Log.e(TAG, "updateScrollState failed", t);
        }
    }

    private void animateBackground() {

        final int startColor = currentBackgroundColor;
        final int targetColor = getTargetColor();

        cancelColorAnimation();

        try {
            colorAnimator = ValueAnimator.ofObject(
                    new ArgbEvaluator(),
                    startColor,
                    targetColor);

            colorAnimator.setDuration(COLOR_CHANGE_DURATION);
            colorAnimator.setInterpolator(
                    new DecelerateInterpolator(DECELERATE_FACTOR));

            colorAnimator.addUpdateListener(
                    new ValueAnimator.AnimatorUpdateListener() {
                        @Override
                        public void onAnimationUpdate(
                                ValueAnimator animation) {
                            try {
                                if (!attached) return;

                                Integer color =
                                        (Integer) animation.getAnimatedValue();
                                if (color == null) return;

                                currentBackgroundColor = color;

                                // Toolbar background.
                                if (backgroundDrawable != null) {
                                    backgroundDrawable.setColor(color);
                                }

                                // Toolbar ripple.
                                if (rippleDrawable != null) {
                                    rippleDrawable.setColor(
                                            ColorStateList.valueOf(
                                                    createRippleColor(color)));
                                    rippleDrawable.invalidateSelf();
                                }

                                // Status bar in lockstep.
                                updateStatusBarColor(color);

                            } catch (Throwable t) {
                                Log.e(TAG,
                                        "color animator frame failed", t);
                            }
                        }
                    });

            colorAnimator.start();

        } catch (Throwable t) {
            Log.e(TAG, "animateBackground failed, snapping to target", t);

            // Snap to the target without animating.
            currentBackgroundColor = targetColor;
            try {
                if (backgroundDrawable != null) {
                    backgroundDrawable.setColor(targetColor);
                }
                updateStatusBarColor(targetColor);
            } catch (Throwable ignored) {}
        }
    }

    private int getTargetColor() {
        return isScrolled ? elevatedSurfaceColor : surfaceColor;
    }

    // ============================================================
    // Status bar
    // ============================================================

    private void createStatusBarScrim() {

        if (decorView == null) {
            // No decor view; only setStatusBarColor will be used.
            updateStatusBarColor(currentBackgroundColor);
            return;
        }

        try {
            ViewOverlay overlay = decorView.getOverlay();

            if (overlay == null) {
                // OEM refuses overlay; fall back to setStatusBarColor.
                updateStatusBarColor(currentBackgroundColor);
                return;
            }

            statusBarScrim = new ColorDrawable(currentBackgroundColor);
            overlay.add(statusBarScrim);

            updateStatusBarScrimBounds();

            // Also set the system status-bar color (older Androids).
            updateStatusBarColor(currentBackgroundColor);

        } catch (Throwable t) {
            Log.e(TAG, "createStatusBarScrim failed", t);
            statusBarScrim = null;
            // Try setStatusBarColor as the only remaining option.
            updateStatusBarColor(currentBackgroundColor);
        }
    }

    private void updateStatusBarColor(int color) {

        // Always update our edge-to-edge scrim if present.
        if (statusBarScrim != null) {
            try {
                statusBarScrim.setColor(color);
                updateStatusBarScrimBounds();
            } catch (Throwable t) {
                Log.e(TAG, "scrim color update failed", t);
            }
        }

        // setStatusBarColor still works on older Androids.
        // On Android 15 (API 35)+ in edge-to-edge it is ignored, but
        // it does not throw, so this is safe to always call.
        if (window != null) {
            try {
                window.setStatusBarColor(color);
            } catch (Throwable ignored) {
                // Some OEMs throw on this in edge-to-edge; ignore.
            }
        }
    }

    private void updateStatusBarScrimBounds() {

        if (decorView == null || statusBarScrim == null) {
            return;
        }

        try {
            int width = decorView.getWidth();
            if (width <= 0) return;

            int statusBarHeight = getStatusBarInsetHeight();
            if (statusBarHeight <= 0) return;

            statusBarScrim.setBounds(0, 0, width, statusBarHeight);
            statusBarScrim.invalidateSelf();

        } catch (Throwable t) {
            Log.e(TAG, "updateStatusBarScrimBounds failed", t);
        }
    }

    /**
     * Returns the height of the status bar in pixels, using the modern
     * insets API on Android 11+ and the legacy API below.
     *
     * The legacy getSystemWindowInsetTop() is deprecated since API 30
     * and typically returns 0 in edge-to-edge mode -- exactly the
     * scenario this class supports. On API 30+ we therefore read
     * WindowInsets.getInsets(Type.statusBars()).
     *
     * Returns 0 if insets are not yet available (e.g. before the first
     * layout pass); callers should retry on the next layout change.
     */
    private int getStatusBarInsetHeight() {

        if (decorView == null) return 0;

        try {
            WindowInsets insets = decorView.getRootWindowInsets();
            if (insets == null) return 0;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets statusBars = insets.getInsets(
                        WindowInsets.Type.statusBars());
                return statusBars != null ? statusBars.top : 0;
            } else {
                return insets.getSystemWindowInsetTop();
            }

        } catch (Throwable t) {
            Log.e(TAG, "getStatusBarInsetHeight failed", t);
            return 0;
        }
    }

    private void removeStatusBarScrim() {

        if (decorView == null || statusBarScrim == null) {
            statusBarScrim = null;
            return;
        }

        try {
            ViewOverlay overlay = decorView.getOverlay();
            if (overlay != null) {
                overlay.remove(statusBarScrim);
            }
        } catch (Throwable t) {
            Log.e(TAG, "removeStatusBarScrim failed", t);
        }

        statusBarScrim = null;
    }

    // ============================================================
    // Utilities
    // ============================================================

    @Nullable
    private static Window findWindow(@NonNull Context context) {

        try {
            Context current = context;
            int guard = 0;

            while (current instanceof ContextWrapper && guard++ < 32) {

                if (current instanceof android.app.Activity) {
                    return ((android.app.Activity) current).getWindow();
                }

                Context next =
                        ((ContextWrapper) current).getBaseContext();

                // Cycle guard: if the wrapper returns itself we stop.
                if (next == current) {
                    return null;
                }

                current = next;
            }

        } catch (Throwable t) {
            Log.e(TAG, "findWindow failed", t);
        }

        return null;
    }

    /**
     * Exact Material 3 Compose algorithm:
     *
     *   alpha  = ((4.5 * ln(elevation + 1)) + 2) / 100
     *   result = surfaceTint.copy(alpha).compositeOver(surface)
     */
    private static int surfaceColorAtElevation(
            int surface,
            int surfaceTint,
            float elevationDp) {

        if (elevationDp <= 0f) {
            return surface;
        }

        float alpha =
                ((4.5f * (float) Math.log(elevationDp + 1f)) + 2f) / 100f;

        float inverseAlpha = 1f - alpha;

        float red   = (Color.red(surfaceTint)   * alpha) + (Color.red(surface)   * inverseAlpha);
        float green = (Color.green(surfaceTint) * alpha) + (Color.green(surface) * inverseAlpha);
        float blue  = (Color.blue(surfaceTint)  * alpha) + (Color.blue(surface)  * inverseAlpha);

        return Color.rgb(
                clampColorChannel((int) (red + 0.5f)),
                clampColorChannel((int) (green + 0.5f)),
                clampColorChannel((int) (blue + 0.5f)));
    }

    private static int clampColorChannel(int value) {
        return Math.max(0, Math.min(255, value));
    }

    private void cancelColorAnimation() {
        try {
            if (colorAnimator != null) {
                colorAnimator.cancel();
                colorAnimator = null;
            }
        } catch (Throwable ignored) {}
    }

    // ============================================================
    // Safe helpers
    // ============================================================

    private int safeThemeColor(int attrResId, int fallback) {
        try {
            return MaterialColors.getColor(view, attrResId, fallback);
        } catch (Throwable t) {
            return fallback;
        }
    }

    private boolean safeIsNightMode() {
        try {
            int flags = context.getResources().getConfiguration().uiMode
                    & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
            return flags == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        } catch (Throwable t) {
            return false;
        }
    }

    // ============================================================
    // Static registry
    // ============================================================

    /**
     * Attaches a helper to the given view. Safe to call from any
     * thread: the instance registry is synchronized. The actual
     * attach() work runs on whatever thread this method is called on;
     * callers should normally use the main thread.
     */
    public static void attach(
            @NonNull Context context,
            @NonNull View view,
            @NonNull TabLayout tabLayout) {

        try {
            MaterialToolbarScrollHelper old;
            synchronized (INSTANCES) {
                old = INSTANCES.remove(view);
            }

            if (old != null) {
                try {
                    old.detach();
                } catch (Throwable t) {
                    Log.e(TAG, "old detach failed", t);
                }
            }

            MaterialToolbarScrollHelper helper =
                    new MaterialToolbarScrollHelper(context, view, tabLayout);

            synchronized (INSTANCES) {
                INSTANCES.put(view, helper);
            }

            helper.attach();

        } catch (Throwable t) {
            Log.e(TAG, "attach failed", t);
        }
    }

    public static void detach(@NonNull View view) {

        try {
            MaterialToolbarScrollHelper helper;
            synchronized (INSTANCES) {
                helper = INSTANCES.remove(view);
            }

            if (helper != null) {
                helper.detach();
            }

        } catch (Throwable t) {
            Log.e(TAG, "detach failed", t);
        }
    }
}